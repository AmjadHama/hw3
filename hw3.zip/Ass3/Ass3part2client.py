import socket

ip = '127.0.0.1'
port = 6666
ADD = (ip, port)
FORMAT = 'ascii'

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(ADD)

while True:
    msg = input("Enter message to send to server: ")
    client.sendall(msg.encode(FORMAT))
    if msg.lower().strip() == 'exit':
        break
    data = client.recv(1024).decode(FORMAT)
    print("Received from server: {}".format(data))

client.close()
