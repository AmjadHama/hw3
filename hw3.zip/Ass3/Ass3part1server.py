import socket

host = socket.gethostname()
ip = socket.gethostbyname(host)
port = 6666
ADD = (ip, port)
FORMAT = 'ascii'

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADD)
server.listen(5)

print("Server is listening on {}:{}".format(ip, port))

conn, add = server.accept()

print("Connected from {}:{}".format(add[0], add[1]))

while True:
    data = conn.recv(1024).decode(FORMAT)
    if not data:
        break
    print("Received from client: {}".format(data))
    reply = input("Enter your response: ")
    conn.sendall(reply.encode(FORMAT))

conn.close()
